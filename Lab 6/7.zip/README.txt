Directions for running:

In windows terminal give command [this command will work if required packages are already installed]

 python 7.py





OR 



To check remotely, open 7.ipynb in Google Colab/Jupyter Notebook and then run accordingly.