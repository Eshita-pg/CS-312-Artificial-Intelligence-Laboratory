Direction to Run:
Write the correct path for the input file on the line number 228 as shown in image "input.png" attached in zip file.
After executing the code, a file "output.txt" is produced which contains the Maze with correct path along with the 'No. of States' and 'Path length',
for the selected traversal method(BFS/DFS/DFID).
