The python file can be executed in IDE.
              
OR 

By typing "python 7.py" in Windows terminal.

After executing program will produce text file "output.txt"